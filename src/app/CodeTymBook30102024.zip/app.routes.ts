import { Routes } from '@angular/router';
import { BodyhomeComponent } from './bodyhome/bodyhome.component';

export const routes: Routes = [
    {path: '', component: BodyhomeComponent},
];
