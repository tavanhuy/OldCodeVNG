import { Component } from '@angular/core';

@Component({
  selector: 'app-headerhome',
  standalone: true,
  imports: [],
  templateUrl: './headerhome.component.html',
  styleUrl: './headerhome.component.css'
})
export class HeaderhomeComponent {

}
