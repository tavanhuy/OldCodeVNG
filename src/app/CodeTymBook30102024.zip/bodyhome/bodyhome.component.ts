import { AfterViewInit, Component, OnInit, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, AfterViewChecked  } from '@angular/core';
import { FooterhomeComponent } from "../footerhome/footerhome.component";
import { HeaderhomeComponent } from "../headerhome/headerhome.component";
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import Swiper from 'swiper';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';

// install Swiper modules
Swiper.use([Navigation, Pagination, Autoplay]);

@Component({
  selector: 'app-bodyhome',
  standalone: true,
  imports: [FooterhomeComponent, HeaderhomeComponent, CommonModule],
  templateUrl: './bodyhome.component.html',
  styleUrls: ['./bodyhome.component.css']
})
export class BodyhomeComponent implements OnInit, AfterViewChecked{
  books: any[] = [];
  image: string[] = [];
  swiperImg: string[] = [];

  imgsload: number = 0;
  i: number = 0;
  flag: boolean = false;
  constructor(private http: HttpClient){}

  ngOnInit():void{
    this.getBook().subscribe(data=>{
      for(let tmp of data.data)
      {
        this.books.push(tmp);
        this.image.push("http://localhost:1337" + tmp.image[0].url);
         
      }

    });
    this.getSwiperImg().subscribe(data =>{
      for(let img of data.data)
      {
        this.swiperImg.push("http://localhost:1337" + img.swiperIMG[0].url);
      }
      this.flag=true;
    });
  }

  ngAfterViewChecked(){
    if(this.flag==true)
    {
      this.initSwiper();
      this.flag = false;

    } 
  }

  initSwiper():void{
      const swiper = new Swiper('.swiper', {  
        loop:true,
        slidesPerView: 1,
        speed: 1000, 
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
        pagination: {
          el: '.swiper-pagination', 
          clickable:true,
        },
        autoplay:{
          delay: 1500,
          disableOnInteraction: false,
        },      
      });
  }                                                                                                                                                                                                                                                                                                                                                                                                                      

  getBook(): Observable<any>{
    return this.http.get<any>("http://localhost:1337/api/Books?populate=*");
  }

  getSwiperImg(): Observable<any>{
    return this.http.get<any>("http://localhost:1337/api/Swipers?populate=*");
  }
}
